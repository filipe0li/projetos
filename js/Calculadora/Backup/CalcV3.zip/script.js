var v2='';
var vR;
var oper;
const vi=visor;

function botao(num){
    vi.value+=num;
}

function reseta(){
    vi.value=''
    v2='';
}

function backspace(){
    vi.value=vi.value.substring(0,vi.value.length -1);
}

function calcule(){
    if (vi.value!=''){
        if(vi.value.includes('-')){
            vi.value='('+vi.value+')';}//verifica se tem sinal de - e coloca entre()
        vR=v2+vi.value;//salva equação antes do resultado
        vi.value=eval(v2+vi.value);//calcula
        dados.push([vR+'= '+vi.value]);//adiciona resultado ao array
        paginar();
        ajustarBotoes();}
}

function clearHist(){
    dados = [];//apaga array
    $("#hist").empty();//apaga na tela
    ajustarBotoes();//arruma botões
    $('#numeracao').text(' 1 - 1 ');//reseta número de páginas
    pagina = 0;//reseta página
}

function verifica(){
    if(v2.includes('+')){
        v2=v2.substring(0,v2.length -1);
        v2+=oper;}
    else if(v2.includes('-')){
        v2=v2.substring(0,v2.length -1);
        v2+=oper;}
    else if(v2.includes('*')){
        v2=v2.substring(0,v2.length -1);
        v2+=oper;}
    else if(v2.includes('/')){
        v2=v2.substring(0,v2.length -1);
        v2+=oper;}
}

function soma(){
    if (vi.value==''){
        oper='+';
        this.verifica();
        }
    else if (vi.value!=''){
        v2=vi.value+='+';
        vi.value='';}
}

function subtrai(){
    if (vi.value==''){
        oper='-';
        this.verifica();
        }
    else if (vi.value!=''){
        v2=vi.value+='-';
        vi.value='';}
}

function multiplca(){
    if (vi.value==''){
        oper='*';
        this.verifica();
        }
    else if (vi.value!=''){
        v2=vi.value+='*';
        vi.value='';}
}

function divide(){
    if (vi.value==''){
        oper='/';
        this.verifica();
        }
    else if (vi.value!=''){
        v2=vi.value+='/';
        vi.value='';}
}

function troca(){
    if (vi.value==''){
        vi.value+='-';}//add - se a tela tiver limpa
    else if(vi.value.includes('-')){
        vi.value=vi.value.substring(1);}//remove - antes do primeiro número
    else{vi.value='-'+vi.value;}//bugou com+= :(  //add - antes do primeiro número
}

var dados = [];//array
const tamanhoPagina = 5;//itens a exibir por página
var pagina = 0;//página atual

function paginar() {
    $("#hist").empty();//limpa tela
for (var i = pagina * tamanhoPagina; i < dados.length && i < (pagina + 1) *  tamanhoPagina; i++) {//divide as páginas
    $('#hist').append("<tr><td>"+dados[i]+"</td></tr>");//adiciona dados do array em tabelas
}
$('#numeracao').text(' '+(pagina + 1) + ' - ' + Math.ceil(dados.length / tamanhoPagina)+' ');//adiciona número de paginas
}

function ajustarBotoes() {
    $('#proximo').prop('disabled', dados.length <= tamanhoPagina || pagina >= Math.ceil(dados.length / tamanhoPagina) - 1);//libera o botão avançar
    $('#anterior').prop('disabled', dados.length <= tamanhoPagina || pagina == 0);//libera o botão voltar
}

function proximo() {
    if (pagina < dados.length / tamanhoPagina - 1) {
        pagina++;
        paginar();
        ajustarBotoes();
    }
}
function anterior() {
    if (pagina > 0) {
        pagina--;
        paginar();
        ajustarBotoes();
    }
}