var v2='';
var vR;
var oper;
const vi=visor;

function botao(num){
    vi.value+=num;
}

function reseta(){
    vi.value=''
    v2='';
}

function backspace(){
    vi.value=vi.value.substring(0,vi.value.length -1);
}

function calcule(){
    if (vi.value!=''){
        vR=v2+vi.value;
        vi.value=eval(v2+vi.value);
        this.historico();}
}

function historico(){
    $("#hist").append("<tr><td>" + vR+'= '+vi.value + "</td></tr>");
}

function clearHist(){
    $("#hist").empty();//apaga TODO resultado
}

function verifica(){
    if(v2.includes('+')){
        v2=v2.substring(0,v2.length -1);
        v2+=oper;}
    else if(v2.includes('-')){
        v2=v2.substring(0,v2.length -1);
        v2+=oper;}
    else if(v2.includes('*')){
        v2=v2.substring(0,v2.length -1);
        v2+=oper;}
    else if(v2.includes('/')){
        v2=v2.substring(0,v2.length -1);
        v2+=oper;}
}

function soma(){
    if (vi.value==''){
        oper='+';
        this.verifica();
        }
    else if (vi.value!=''){
        v2=vi.value+='+';
        vi.value='';}
}

function subtrai(){
    if (vi.value==''){
        oper='-';
        this.verifica();
        }
    else if (vi.value!=''){
        v2=vi.value+='-';
        vi.value='';}
}

function multiplca(){
    if (vi.value==''){
        oper='*';
        this.verifica();
        }
    else if (vi.value!=''){
        v2=vi.value+='*';
        vi.value='';}
}

function divide(){
    if (vi.value==''){
        oper='/';
        this.verifica();
        }
    else if (vi.value!=''){
        v2=vi.value+='/';
        vi.value='';}
}

function troca(){
    if (vi.value==''){
        vi.value+='-';}
    else if(vi.value.includes('-')){
        vi.value=vi.value.substring(1);}
    else{vi.value='-'+vi.value;}//bugou com+= :(
}